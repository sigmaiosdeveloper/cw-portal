
go build cw-portal/main.go


mv cw-portal/cw-portal /usr/local/bin


rm -rf cw-portal




echo installed 