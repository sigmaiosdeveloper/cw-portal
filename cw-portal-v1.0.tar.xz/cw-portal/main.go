/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>

*/
package main

import "cw-portal/cmd"

func main() {
	cmd.Execute()
}
