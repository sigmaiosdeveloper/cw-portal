package cmd

import "fmt"
import "github.com/spf13/cobra"
var verbose bool
func init() {
  rootCmd.AddCommand(versionCmd)
  rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "use verbose output")
  
}


var versionCmd = &cobra.Command{
  Use: "version",
  Short: "print version",
  Run: func(cmd *cobra.Command, args []string) {
    fmt.Println("Version 1.0")
  },
  
}
