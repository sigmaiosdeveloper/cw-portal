package cmd

import (
  
  "net/http"
	"fmt"
	"github.com/spf13/cobra"
  "encoding/json"
  "bytes"
  "io/ioutil"
)
type user struct {
  Name string `json:"name"`
  Age int `json:"age"`
}
var name string
var age int
var url string = "https://dca15b34-6e37-42b3-970c-ed20ba543c4e-00-2st6uhmn5pni1.worf.replit.dev/addattendee"
var configureCmd = &cobra.Command{
	Use:   "configure",
	Short: "Configure student info",
	Long:  "Usage: ./cw-portal configure -",
	Run: func(cmd *cobra.Command, args []string) {
    
		if name == "" && age == 0 {
			fmt.Println("Please specify a name and age. for usage, enter ./cw-portal configure --help")
		} else {
      data := user {
        Name: name,
        Age: age,
        
      }
      jsondata, err := json.Marshal(data)
      if err != nil {
        fmt.Println(err)
      }
      req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsondata))
      req.Header.Set("Content-Type", "application/json")
      client := &http.Client{}
      resp, err := client.Do(req)
      if err != nil {
        fmt.Println(err)
        return
      }
      defer resp.Body.Close()
      body , err := ioutil.ReadAll(resp.Body)
      if err != nil {
        fmt.Println(err)
        return
      }
      fmt.Println("could be wrong: ", body)

      
      fmt.Println("success! your data is now in the cloud!")
		}
	},
}

func init() {
	rootCmd.AddCommand(configureCmd)
	
	configureCmd.Flags().StringVarP(&name, "name", "n", "", "set name")
	configureCmd.Flags().IntVarP(&age, "age", "a", 0, "set age")
}
