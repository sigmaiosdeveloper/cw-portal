package cmd
import (
  "fmt"
  "net/http"
  "github.com/spf13/cobra"
  "io"
)

type Person struct {
  Name string `json:"name"`
  Age  int    `json:"age"`
}
var whoamicmd = &cobra.Command {
  Use: "whoami",
  Short: "get user info",
  Run: func(cmd *cobra.Command, args []string) {
    fmt.Println("find your name here:")
    resp, err := http.Get("https://dca15b34-6e37-42b3-970c-ed20ba543c4e-00-2st6uhmn5pni1.worf.replit.dev/attendeelist")
    if err != nil {
      panic(err)
    }
    defer resp.Body.Close()
    body, err := io.ReadAll(resp.Body)
    fmt.Println(string(body))
  },
}


func init() {
  rootCmd.AddCommand(whoamicmd)
  
}