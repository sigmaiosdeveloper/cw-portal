/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>

*/
package cmd

import (
	"os"
	"fmt"
	"github.com/spf13/cobra"
)
var rootCmd = &cobra.Command{
	Use:   "cw-portal",
	Short: "A student CLI for the cloudcamp club",
	Long: `Variables here are volatile. You do not need to do anything on your side, but know that every time you instructor shuts the server down, your registration will be deleted. configure your CLI every class.`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("use an option or see ./cw-portal -h for help")
	},
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}